// src/App.tsx

import "./App.css";
import GameManager from "./components/managers/GameManager";

export default function App() {
  return (
    <div className="App">
      <GameManager />
    </div>
  );
}
