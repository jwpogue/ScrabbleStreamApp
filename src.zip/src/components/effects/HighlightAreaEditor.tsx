// src/components/editors/effects/HighlightAreaEditor.tsx
import React from "react";
import type { Effect } from "../../types/ScrabbleTypes";

interface HighlightAreaEditorProps {
  effect: Effect;
  onChange: (effect: Effect) => void;
}

export default function HighlightAreaEditor({ effect, onChange }: HighlightAreaEditorProps) {
  return (
    <div>
      <p>Area Highlights: (Coming soon!)</p>
    </div>
  );
}