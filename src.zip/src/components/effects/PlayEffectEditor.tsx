import React from "react";
import BoardEditor from "../editors/BoardEditor";
import type { PlayEffect, Tile } from "../../types/ScrabbleTypes";

interface PlayEffectEditorProps {
  effect: PlayEffect;
  updateEffect: (updated: Partial<PlayEffect>) => void;
  liveBoard: Tile[][];
  commitBoard: (newBoard: Tile[][]) => void;
}

export default function PlayEffectEditor({
  effect,
  updateEffect,
  liveBoard,
  commitBoard,
}: PlayEffectEditorProps) {
  return (
    <div className="effect-editor">
      <BoardEditor
        liveBoard={liveBoard}
        commitBoard={commitBoard}
      />
    </div>
  );
}
