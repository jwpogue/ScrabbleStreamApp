// src/components/editors/effects/HighlightTileEditor.tsx
import React from "react";
import type { Effect } from "../../types/ScrabbleTypes";

interface HighlightTileEditorProps {
  effect: Effect;
  onChange: (effect: Effect) => void;
}

export default function HighlightTileEditor({ effect, onChange }: HighlightTileEditorProps) {
  const [x, y] = effect.type === "highlight-tile" ? effect.position : [0, 0];

  return (
    <div>
      <label>
        X:
        <input
          type="number"
          value={x}
          onChange={(e) =>
            onChange({ ...effect, position: [parseInt(e.target.value, 10), y] })
          }
        />
      </label>
      <label>
        Y:
        <input
          type="number"
          value={y}
          onChange={(e) =>
            onChange({ ...effect, position: [x, parseInt(e.target.value, 10)] })
          }
        />
      </label>
    </div>
  );
}