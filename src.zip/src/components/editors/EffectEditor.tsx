import React from "react";
import type { Effect, Tile } from "../../types/ScrabbleTypes";
import PlayEffectEditor from "../effects/PlayEffectEditor";
// (others omitted for now)

interface EffectEditorProps {
  effect: Effect;
  liveBoard: Tile[][];
  commitBoard: (newBoard: Tile[][]) => void;
  onChange: (updated: Effect) => void;
}

export default function EffectEditor({
  effect,
  liveBoard,
  commitBoard,
  onChange,
}: EffectEditorProps) {
  switch (effect.type) {
    case "play":
      return (
        <PlayEffectEditor
          effect={effect.payload}
          updateEffect={(partial) =>
            onChange({ type: "play", payload: { ...effect.payload, ...partial } })
          }
          liveBoard={liveBoard}
          commitBoard={commitBoard}
        />
      );

    case "highlight":
      return <div>Highlight effect editor not implemented yet</div>;

    case "none":
    default:
      return <div className="text-sm text-gray-400">No effect selected.</div>;
  }
}
