import React, { useMemo } from "react";
import type {
  Effect,
  FrameNode,
  SequenceNode,
  Tile,
  TilePlacement,
} from "../../types/ScrabbleTypes";
import EffectEditor from "./EffectEditor";
import { computeBoardAtFrame } from "../../lib/engine";

interface FrameEditorProps {
  frame: FrameNode;
  rootSequence: SequenceNode;
  frameIndex: number;
  boardSize: number;
  updateEffect: (newEffect: Effect) => void;
}

const FrameEditor: React.FC<FrameEditorProps> = ({
  frame,
  rootSequence,
  frameIndex,
  boardSize,
  updateEffect,
}) => {
  const liveBoard: Tile[][] = useMemo(() => {
    return computeBoardAtFrame(rootSequence, frameIndex, boardSize);
  }, [rootSequence, frameIndex, boardSize]);

  const handleTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newType = e.target.value as Effect["type"];
    const defaultEffect = createDefaultEffect(newType);
    updateEffect(defaultEffect);
  };

  const commitBoard = (newBoard: Tile[][]) => {
    // Only valid for play effects
    if (frame.effect.type !== "play") return;

    const tiles: TilePlacement[] = [];
    for (let y = 0; y < newBoard.length; y++) {
      for (let x = 0; x < newBoard[y].length; x++) {
        const cell = newBoard[y][x];
        if (cell.state === "unlocked" && cell.letter) {
          tiles.push({ x, y, letter: cell.letter });
        }
      }
    }

    updateEffect({ type: "play", payload: { tiles } });
  };

  return (
    <div className="frame-editor">
      <h3>Frame Editor</h3>

      <label>
        Effect Type:
        <select value={frame.effect.type} onChange={handleTypeChange}>
          {Object.keys(effectTypeOptions).map((type) => (
            <option key={type} value={type}>
              {effectTypeOptions[type as Effect["type"]]}
            </option>
          ))}
        </select>
      </label>

      <EffectEditor
        effect={frame.effect}
        onChange={updateEffect}
        liveBoard={liveBoard}
        commitBoard={commitBoard}
      />
    </div>
  );
};

const effectTypeOptions: Record<Effect["type"], string> = {
  play: "Play Tiles",
  highlight: "Highlight Tile",
  none: "None",
};

function createDefaultEffect(type: Effect["type"]): Effect {
  switch (type) {
    case "play":
      return { type: "play", payload: { tiles: [] } };
    case "highlight":
      return { type: "highlight", payload: { squares: [] } };
    case "none":
    default:
      return { type: "none", payload: {} };
  }
}

export default FrameEditor;
